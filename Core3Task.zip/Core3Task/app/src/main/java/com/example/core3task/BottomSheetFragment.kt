package com.example.core3task



import android.content.Context

import android.os.Bundle

import android.view.*

import android.widget.TextView

import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class BottomSheetFragment : BottomSheetDialogFragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.bottomsheet_fragment,container,false)
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val nameTV = view.findViewById<TextView>(R.id.name_country)
        val goldTV = view.findViewById<TextView>(R.id.gold_country)
        val silverTV = view.findViewById<TextView>(R.id.silver_country)
        val bronzeTV = view.findViewById<TextView>(R.id.bronze_country)
        val iocTV = view.findViewById<TextView>(R.id.ioc_country)
        val activity = activity as Context

        val sharedPreferences = activity.getSharedPreferences("sharedPrefs", Context.MODE_PRIVATE)
        val nameText = sharedPreferences.getString("NAME", null)
        val goldText = sharedPreferences.getInt("GOLD", 0)
        val silverText = sharedPreferences.getInt("SILVER", 0)
        val bronzeText = sharedPreferences.getInt("BRONZE", 0)
        val iocText = sharedPreferences.getString("IOC", null)

        nameTV.text = nameText
        goldTV.text = goldText.toString().plus(" gold medals")
        silverTV.text = silverText.toString().plus(" silver medals")
        bronzeTV.text = bronzeText.toString().plus(" bronze medals")
        iocTV.text = iocText
    }

}