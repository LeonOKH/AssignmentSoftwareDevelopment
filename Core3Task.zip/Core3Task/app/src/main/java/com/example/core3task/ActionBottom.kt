package com.example.core3task

class ActionBottom {
    companion object{
        const val TAG ="ActionBottomDialog"
        fun newInstance():BottomSheetFragment{
            return BottomSheetFragment()
        }
    }
}