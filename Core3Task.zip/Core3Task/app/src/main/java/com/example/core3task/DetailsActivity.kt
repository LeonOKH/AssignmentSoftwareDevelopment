package com.example.core3task

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DetailsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.details_activity)

        val SharedPref = getSharedPreferences("sharedPrefs", MODE_PRIVATE)
        val textview = findViewById<TextView>(R.id.lastMedallist_tv)

         val name = SharedPref.getString("NAME", null)

        val ioc = SharedPref.getString("IOC", null)
        val statement = "The last country clicked was $name ($ioc)"
        textview.text =  statement

    }


}