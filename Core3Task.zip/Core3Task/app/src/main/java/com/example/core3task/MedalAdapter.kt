package com.example.core3task

import android.content.Context

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView

import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.medal_layout.view.*

class MedalAdapter(private val data: List<Medallist>): RecyclerView.Adapter<MedalAdapter.customViewHolder>(){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): customViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val cellForRow = layoutInflater.inflate(R.layout.medal_layout, parent, false)
        return customViewHolder(cellForRow)
    }

    override fun onBindViewHolder(holder: customViewHolder, position: Int) {
        val item = data[position]
        holder.bind(item)
        val topTen = getTopTen()
        if(data[position].ioc in topTen) {
            holder.itemView.medalList.setBackgroundResource(R.color.purple_200)
            holder.icon_medal.setImageResource(R.drawable.medal2)
        } else {
            holder.itemView.medalList.setBackgroundResource(R.color.white)
            holder.icon_medal.setImageResource(0)
        }
    }
    private fun getTopTen() : MutableList<String>
    {
        val topTen = mutableListOf<String>()
        val myList = mutableListOf<TotalCount>()

        val c = data.size - 1
        for (i in 0..c) {
            val ioc = data[i].ioc
            val totalMedalCount = data[i].getTotal()
            myList.add(TotalCount(ioc, totalMedalCount))
        }
        myList.sortByDescending {
            it.totalMedal
        }
        for (i in 0..9) {
            topTen.add(myList[i].ioc)
        }
        return topTen
    }

    override fun getItemCount(): Int {
        return data.size
    }


    class customViewHolder(v: View): RecyclerView.ViewHolder(v){
        val medallistTitle = itemView.findViewById<TextView>(R.id.medallistName)
        val medallistIOC = itemView.findViewById<TextView>(R.id.medallistIOC)
        val medalCount= itemView.findViewById<TextView>(R.id.medalCount)
        val icon_medal= itemView.findViewById<ImageView>(R.id.icon_medal)
        fun bind(item:Medallist){
            medallistTitle.text = item.name
            medallistIOC.text = item.ioc
            medalCount.text= item.getTotal().toString()


            itemView.setOnClickListener {

                    val activity = itemView.context as AppCompatActivity


                val addPhotoBottomDialogFragment = ActionBottom.newInstance()
                addPhotoBottomDialogFragment.show(activity.supportFragmentManager, ActionBottom.TAG)

                val SharedPref = activity.getSharedPreferences("sharedPrefs", Context.MODE_PRIVATE)
                val editor = SharedPref.edit()
                editor.apply{
                putString("NAME", item.name)
                putInt("GOLD", item.gold)
                putInt("SILVER",  item.silver)
               putInt("BRONZE",  item.bronze)
                putString("IOC", item.ioc)
                }.apply()

                }
            }
        }




}

