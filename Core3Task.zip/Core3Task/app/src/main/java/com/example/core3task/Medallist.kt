package com.example.core3task
data class TotalCount(
    var ioc: String = "",
    var totalMedal: Int = 0,

    )
data class Medallist(
    var name: String = "",
    var ioc: String = "",
    var timesCompeted: Int = 0,
    var gold: Int = 0,
    var silver: Int = 0,
    var bronze: Int = 0,

)
{
    fun getTotal(): Int{
        return this.gold + this.silver + this.bronze
    }
}