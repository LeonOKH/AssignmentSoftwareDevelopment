package com.example.core3task


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.InputStream

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val list = mutableListOf<Medallist>()

            val myInputStream: InputStream = resources.openRawResource(R.raw.medallists)
            val reader = myInputStream.bufferedReader()
            reader.readLine()

            var line = reader.readLine()
            while( line != null) {
                val temp: List<String> = line.split(",")
                val listItem = Medallist(temp[0],
                    temp[1],
                    temp[2].toInt(),
                    temp[3].toInt(),
                    temp[4].toInt(),
                    temp[5].toInt())

                list.add(listItem)
                line = reader.readLine()
            }


        val rvRecyclerView = findViewById<RecyclerView>(R.id.rv_recyclerview)
        rvRecyclerView.layoutManager = LinearLayoutManager(this)
        rvRecyclerView.adapter = MedalAdapter(list)
    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.save_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if(id == R.id.action_save) {

val intent = Intent(this,DetailsActivity::class.java)
                startActivity(intent)
                return true

        }
        return super.onOptionsItemSelected(item)
    }

}